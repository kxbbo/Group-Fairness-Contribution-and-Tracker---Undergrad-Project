<?php

use App\Http\Controllers\CourseController;
use App\Http\Controllers\EvidenceController;
use App\Http\Controllers\PeerRatingController;
use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('home');
})->name('home');

// Simulated user switch for testing role and task rules
Route::post('/switch-user', [TaskController::class, 'switchUser'])->name('user.switch');

// Feature 1: Course and Fairness-Formula Setup (Member 1)
Route::get('/courses', [CourseController::class, 'index'])->name('courses.index');
Route::get('/courses/create', [CourseController::class, 'create'])->name('courses.create');
Route::post('/courses', [CourseController::class, 'store'])->name('courses.store');
Route::get('/courses/{id}/edit', [CourseController::class, 'edit'])->name('courses.edit');
Route::put('/courses/{id}', [CourseController::class, 'update'])->name('courses.update');

// Feature 11: Evidence Vault
Route::prefix('evidence')->name('evidence.')->group(function () {
    Route::get('/', [EvidenceController::class, 'tasks'])->name('tasks');
    Route::get('/tasks', [EvidenceController::class, 'tasks'])->name('tasks.list');
    Route::get('/{taskId}', [EvidenceController::class, 'index'])->whereNumber('taskId')->name('index');
    Route::get('/{taskId}/create', [EvidenceController::class, 'create'])->whereNumber('taskId')->name('create');
    Route::post('/{taskId}', [EvidenceController::class, 'store'])->whereNumber('taskId')->name('store');
    Route::delete('/{taskId}/{id}', [EvidenceController::class, 'destroy'])
        ->whereNumber('taskId')->whereNumber('id')->name('destroy');
    Route::get('/{taskId}/{id}/download', [EvidenceController::class, 'download'])
        ->whereNumber('taskId')->whereNumber('id')->name('download');
});

// Feature 6: Weighted Task Management
Route::get('/tasks', [TaskController::class, 'teams'])->name('tasks.teams');
Route::get('/teams/{teamId}/tasks', [TaskController::class, 'index'])->name('tasks.index');
Route::get('/teams/{teamId}/tasks/create', [TaskController::class, 'create'])->name('tasks.create');
Route::post('/teams/{teamId}/tasks', [TaskController::class, 'store'])->name('tasks.store');
Route::get('/tasks/{id}/edit', [TaskController::class, 'edit'])->name('tasks.edit');
Route::put('/tasks/{id}', [TaskController::class, 'update'])->name('tasks.update');
Route::patch('/tasks/{id}/status', [TaskController::class, 'updateStatus'])->name('tasks.updateStatus');
Route::delete('/tasks/{id}', [TaskController::class, 'destroy'])->name('tasks.destroy');

// Feature 16: Anonymous Peer Evaluation Rounds (Member 4)
Route::prefix('evaluations')->name('evaluations.')->group(function () {
    Route::get('/', [PeerRatingController::class, 'index'])->name('index');
    Route::get('/{roundId}', [PeerRatingController::class, 'create'])->name('create');
    Route::post('/{roundId}', [PeerRatingController::class, 'store'])->name('store');
    Route::get('/{roundId}/receipt', [PeerRatingController::class, 'show'])->name('show');
    Route::post('/{roundId}/status', [PeerRatingController::class, 'toggleStatus'])->name('toggleStatus');
    Route::post('/rounds', [PeerRatingController::class, 'storeRound'])->name('storeRound');
    Route::post('/reset-demo', [PeerRatingController::class, 'resetDemoRatings'])->name('resetDemo');
});
